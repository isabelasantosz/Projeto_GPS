public class Calculadora {

    public int subtraInt(int a, int b) {
        return a - b;
    }

    public int multiInteiros(int a, int b) {
        return a * b;
    }

    public int diviInteiros(int a, int b) {
        if (b != 0) {
            return a / b;
        } else {
            throw new ArithmeticException("Não é permitida a divisão por 0");
        }
    }

    public static void main(String[] args) {
        // Exemplo de uso dos métodos
        Calculadora calculadora = new Calculadora();
        System.out.println("Subtração: " + calculadora.subtraInt(9, 3));
        System.out.println("Multiplicação: " + calculadora.multiInteiros(2, 6));
        System.out.println("Divisão: " + calculadora.diviInteiros(4, 2));
    }
}
